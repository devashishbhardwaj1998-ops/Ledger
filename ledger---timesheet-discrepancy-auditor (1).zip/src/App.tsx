import React, { useState, useEffect, useRef } from 'react';
import { Play, AlertTriangle, ArrowRight } from 'lucide-react';
import { RawEmployeeRow, RawEmployerRow, AuditReportData } from './types';
import { lastWeekWindow } from './utils/parser';
import { runInvestigation } from './utils/audit';
import { Masthead } from './components/Masthead';
import { IntakeSlots } from './components/IntakeSlots';
import { EmployeePicker } from './components/EmployeePicker';
import { DateRangePicker } from './components/DateRangePicker';
import { DiscrepancyReport } from './components/DiscrepancyReport';
import { MappingLegendModal } from './components/MappingLegendModal';

export default function App() {
  const [employeeFile, setEmployeeFile] = useState<{ name: string; sizeText?: string } | null>(null);
  const [employerFile, setEmployerFile] = useState<{ name: string; sizeText?: string } | null>(null);
  const [employeeRows, setEmployeeRows] = useState<RawEmployeeRow[] | null>(null);
  const [employerRows, setEmployerRows] = useState<RawEmployerRow[] | null>(null);

  const [selectedNameKey, setSelectedNameKey] = useState<string>('');
  const [selectedDisplayName, setSelectedDisplayName] = useState<string>('');
  const [typedName, setTypedName] = useState<string>('');

  const [rangeStart, setRangeStart] = useState<string>('');
  const [rangeEnd, setRangeEnd] = useState<string>('');

  const [report, setReport] = useState<AuditReportData | null>(null);
  const [errorNote, setErrorNote] = useState<string | null>(null);
  const [isLegendOpen, setIsLegendOpen] = useState(false);

  const reportRef = useRef<HTMLDivElement>(null);

  // Initialize date range with sensible default (last week)
  useEffect(() => {
    const w = lastWeekWindow();
    setRangeStart(w.start);
    setRangeEnd(w.end);
  }, []);

  // Update selectedNameKey whenever typedName resolves directly or user picks from list
  const handleTypedNameChange = (val: string) => {
    setTypedName(val);
    if (!employeeRows || !employeeRows.length) return;

    const clean = val.trim().replace(/\s+/g, ' ');
    const lower = clean.toLowerCase();

    // Check exact nameKey match
    const hit = employeeRows.find((r) => r.nameKey === lower);
    if (hit) {
      setSelectedNameKey(hit.nameKey);
      setSelectedDisplayName(hit.name);
      return;
    }

    // Check split first / last
    const words = clean.split(' ');
    if (words.length >= 2) {
      const typedLast = words[words.length - 1].toLowerCase();
      const typedFirst = words.slice(0, -1).join(' ').toLowerCase();
      const splitHit = employeeRows.find(
        (r) =>
          r.firstName.toLowerCase() === typedFirst &&
          r.lastName.toLowerCase() === typedLast
      );
      if (splitHit) {
        setSelectedNameKey(splitHit.nameKey);
        setSelectedDisplayName(splitHit.name);
        return;
      }
    }

    setSelectedNameKey('');
    setSelectedDisplayName('');
  };

  const handleSelectEmployee = (nameKey: string, displayName: string) => {
    setSelectedNameKey(nameKey);
    setSelectedDisplayName(displayName);
    setTypedName(displayName);
    setErrorNote(null);
  };

  // Readiness calculations
  const filesReady = Boolean(employeeFile && employerFile && employeeRows && employerRows);
  const nameChosen = Boolean(selectedNameKey);
  const rangeChosen = Boolean(rangeStart && rangeEnd);
  const rangeValid = rangeChosen && rangeStart <= rangeEnd;
  const isReadyToInvestigate = filesReady && nameChosen && rangeValid;

  let statusMessage = 'Awaiting both files';
  if (!employeeFile && !employerFile) {
    statusMessage = 'Awaiting the Data Pull Sheet (Exhibit A) and the Daily Planning Sheet (Exhibit B).';
  } else if (!employeeFile) {
    statusMessage = 'Waiting on Exhibit A (Data Pull Sheet).';
  } else if (!employerFile) {
    statusMessage = 'Waiting on Exhibit B (Daily Planning Sheet or Google Sheet).';
  } else if (!nameChosen) {
    statusMessage = 'Type or select which employee to audit.';
  } else if (!rangeChosen) {
    statusMessage = 'Pick a date range to audit.';
  } else if (!rangeValid) {
    statusMessage = 'The "From" date must be on or before the "To" date.';
  } else {
    statusMessage = 'Ready to investigate.';
  }

  const handleInvestigate = () => {
    setErrorNote(null);
    if (!employeeRows || !employerRows || !selectedNameKey) return;

    try {
      const auditResult = runInvestigation(
        employeeRows,
        employerRows,
        selectedNameKey,
        selectedDisplayName,
        rangeStart,
        rangeEnd,
        employeeFile?.name || 'Exhibit A',
        employerFile?.name || 'Exhibit B'
      );
      setReport(auditResult);

      setTimeout(() => {
        const el = document.getElementById('report');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    } catch (err: any) {
      setErrorNote(err.message || 'Audit investigation failed.');
    }
  };

  return (
    <div className="min-h-screen text-[var(--ink)]">
      <div className="max-w-[1060px] mx-auto px-4 sm:px-7 py-8 sm:py-12 pb-28">
        {/* Masthead */}
        <Masthead onOpenLegend={() => setIsLegendOpen(true)} />

        {/* Lede Explainer */}
        <div className="font-serif text-[15px] sm:text-[16.5px] leading-relaxed text-[#3a4139] max-w-3xl mb-8 border-l-2 border-[var(--rule)] pl-4 sm:pl-5">
          Link the Data Pull Sheet (a Google Sheet with every worker&apos;s task-level rows: asset, date, minutes, <code className="bg-[#e2e6df] px-1.5 py-0.5 text-[14px] font-mono">type</code>) and upload the Daily planning sheet (asset, date, Production/Review category). Ledger picks one employee out of the Data Pull Sheet, keeps only <code className="bg-[#e2e6df] px-1.5 py-0.5 text-[14px] font-mono">UpdatedReviewFull</code>, <code className="bg-[#e2e6df] px-1.5 py-0.5 text-[14px] font-mono">UpdatedReviewLimited</code>, <code className="bg-[#e2e6df] px-1.5 py-0.5 text-[14px] font-mono">UpdatedFull</code>, and <code className="bg-[#e2e6df] px-1.5 py-0.5 text-[14px] font-mono">UpdatedLimited</code> rows, translates them into the Daily planning sheet&apos;s matching Production/Review category, and matches every task by <strong className="text-[var(--ink)]">asset name + date</strong> to find mismatches or tasks missing on either side.
        </div>

        {/* Intake File Zones */}
        <IntakeSlots
          employeeFile={employeeFile}
          employerFile={employerFile}
          onEmployeeLoaded={(info, rows) => {
            setEmployeeFile(info);
            setEmployeeRows(rows);
            setErrorNote(null);
            // If previous selected name is in new rows, keep it; else clear
            if (selectedNameKey && !rows.some((r) => r.nameKey === selectedNameKey)) {
              setSelectedNameKey('');
              setSelectedDisplayName('');
              setTypedName('');
            }
          }}
          onEmployerLoaded={(info, rows) => {
            setEmployerFile(info);
            setEmployerRows(rows);
            setErrorNote(null);
          }}
          onClearEmployee={() => {
            setEmployeeFile(null);
            setEmployeeRows(null);
            setSelectedNameKey('');
            setSelectedDisplayName('');
            setTypedName('');
            setReport(null);
          }}
          onClearEmployer={() => {
            setEmployerFile(null);
            setEmployerRows(null);
            setReport(null);
          }}
          onError={(msg) => setErrorNote(msg)}
        />

        {/* Employee Picker */}
        {employeeRows && employeeRows.length > 0 && (
          <EmployeePicker
            employeeRows={employeeRows}
            selectedNameKey={selectedNameKey}
            typedName={typedName}
            onTypedNameChange={handleTypedNameChange}
            onSelectEmployee={handleSelectEmployee}
          />
        )}

        {/* Date Range Picker */}
        <DateRangePicker
          rangeStart={rangeStart}
          rangeEnd={rangeEnd}
          onRangeStartChange={(val) => {
            setRangeStart(val);
            setErrorNote(null);
          }}
          onRangeEndChange={(val) => {
            setRangeEnd(val);
            setErrorNote(null);
          }}
          onApplyPreset={(start, end) => {
            setRangeStart(start);
            setRangeEnd(end);
            setErrorNote(null);
          }}
        />

        {/* Action Trigger Row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 border border-[var(--ink)] bg-white/70">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[var(--brass)] shrink-0 animate-pulse" />
            <span className="font-mono text-[12px] text-[#5a6157]">
              {statusMessage}
            </span>
          </div>

          <button
            type="button"
            disabled={!isReadyToInvestigate}
            onClick={handleInvestigate}
            className="font-mono text-[13px] font-bold tracking-[1.5px] uppercase bg-[var(--ink)] text-[var(--paper)] px-8 py-3.5 hover:bg-[#2a3542] active:translate-y-[1px] disabled:bg-[#aab0a4] disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Investigate</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Error Note Banner */}
        {errorNote && (
          <div className="mt-4 p-4 bg-[var(--flag-bg)] border border-[var(--flag)] text-[var(--flag)] font-mono text-[12.5px] flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            <div className="whitespace-pre-wrap leading-relaxed">{errorNote}</div>
          </div>
        )}

        {/* Discrepancy Findings Report */}
        {report && (
          <div ref={reportRef}>
            <DiscrepancyReport report={report} />
          </div>
        )}

        {/* Footer */}
        <footer className="mt-20 pt-5 border-t border-[var(--rule)] font-mono text-[11px] text-[#8a9086] text-center leading-relaxed">
          Ledger runs entirely in this browser tab. Uploaded files are never sent anywhere; a linked Google Sheet is fetched directly from your browser to Google.
        </footer>
      </div>

      {/* Translation Table Specification Modal */}
      <MappingLegendModal
        isOpen={isLegendOpen}
        onClose={() => setIsLegendOpen(false)}
      />
    </div>
  );
}
