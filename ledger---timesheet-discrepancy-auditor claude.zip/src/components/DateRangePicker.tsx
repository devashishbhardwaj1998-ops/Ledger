import React from 'react';
import { Calendar, AlertCircle, Sparkles } from 'lucide-react';
import { lastWeekWindow, formatDateDDMMYYYY } from '../utils/parser';

interface DateRangePickerProps {
  rangeStart: string;
  rangeEnd: string;
  detectedRange?: { start: string; end: string } | null;
  rangeSource?: 'detected' | 'manual' | 'default';
  onRangeStartChange: (val: string) => void;
  onRangeEndChange: (val: string) => void;
  onApplyPreset: (start: string, end: string) => void;
  onUseDetected?: () => void;
}

export const DateRangePicker: React.FC<DateRangePickerProps> = ({
  rangeStart,
  rangeEnd,
  detectedRange,
  rangeSource,
  onRangeStartChange,
  onRangeEndChange,
  onApplyPreset,
  onUseDetected
}) => {
  const isInvalid = rangeStart && rangeEnd && rangeStart > rangeEnd;

  const handleLastWeek = () => {
    const w = lastWeekWindow();
    onApplyPreset(w.start, w.end);
  };

  const handleThisWeek = () => {
    const today = new Date();
    const currentDay = today.getDay(); // 0 = Sunday
    const start = new Date(today);
    start.setDate(today.getDate() - currentDay);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);

    const toIso = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    onApplyPreset(toIso(start), toIso(end));
  };

  const handlePast14Days = () => {
    const today = new Date();
    const start = new Date(today);
    start.setDate(today.getDate() - 14);

    const toIso = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    onApplyPreset(toIso(start), toIso(today));
  };

  const handleFullMonth = () => {
    const today = new Date();
    const start = new Date(today.getFullYear(), today.getMonth(), 1);
    const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    const toIso = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    onApplyPreset(toIso(start), toIso(end));
  };

  return (
    <div className="border border-[var(--ink)] p-5 sm:p-6 mb-6 bg-white/50">
      <div className="flex items-center justify-between gap-2 mb-1">
        <span className="font-mono text-[10px] tracking-[2px] uppercase text-[var(--brass)] font-bold">
          Reporting Window &bull; Format DD-MM-YYYY
        </span>
        <div className="flex items-center gap-1 font-mono text-[11px] text-[#5a6157]">
          <Calendar className="w-3.5 h-3.5" />
          <span>DD-MM-YYYY Standard</span>
        </div>
      </div>

      <h3 className="font-serif font-bold text-xl text-[var(--ink)] mb-1">
        Pick the date range to audit
      </h3>
      <p className="font-mono text-[11px] text-[#5a6157] mb-3.5 leading-relaxed">
        Only tasks dated within this range are compared. Tasks falling outside the window are excluded from both sides.
      </p>

      {detectedRange && (
        <div
          className={`flex flex-wrap items-center justify-between gap-2 mb-3.5 px-3 py-2 border font-mono text-[11px] ${
            rangeSource === 'detected'
              ? 'border-[var(--ok)] bg-[var(--ok-bg)] text-[var(--ok)]'
              : 'border-[var(--rule)] bg-white/60 text-[#5a6157]'
          }`}
        >
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
            {rangeSource === 'detected' ? (
              <span>
                Auto-set from the Data Pull Sheet&apos;s actual dates: <strong>{formatDateDDMMYYYY(detectedRange.start)}</strong> to <strong>{formatDateDDMMYYYY(detectedRange.end)}</strong>
              </span>
            ) : (
              <span>
                Data Pull Sheet covers <strong>{formatDateDDMMYYYY(detectedRange.start)}</strong> to <strong>{formatDateDDMMYYYY(detectedRange.end)}</strong>, but you&apos;ve set a different range.
              </span>
            )}
          </span>
          {rangeSource !== 'detected' && onUseDetected && (
            <button
              type="button"
              onClick={onUseDetected}
              className="text-[var(--brass)] hover:text-[var(--ink)] font-semibold underline shrink-0"
            >
              Use detected range
            </button>
          )}
        </div>
      )}

      {/* Inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="rangeStartInput"
              className="block font-mono text-[10.5px] uppercase tracking-wider text-[#5a6157] font-semibold"
            >
              From Date
            </label>
            {rangeStart && (
              <span className="font-mono text-[11px] text-[var(--ink)] font-bold bg-[#edf1ea] px-1.5 py-0.5 rounded-xs">
                {formatDateDDMMYYYY(rangeStart)}
              </span>
            )}
          </div>
          <input
            id="rangeStartInput"
            type="date"
            value={rangeStart}
            onChange={(e) => onRangeStartChange(e.target.value)}
            className="w-full font-mono text-[13px] px-3 py-2 border-1.5 border-[var(--rule)] bg-white text-[var(--ink)] focus:outline-none focus:border-[var(--brass)]"
          />
        </div>
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="rangeEndInput"
              className="block font-mono text-[10.5px] uppercase tracking-wider text-[#5a6157] font-semibold"
            >
              To Date
            </label>
            {rangeEnd && (
              <span className="font-mono text-[11px] text-[var(--ink)] font-bold bg-[#edf1ea] px-1.5 py-0.5 rounded-xs">
                {formatDateDDMMYYYY(rangeEnd)}
              </span>
            )}
          </div>
          <input
            id="rangeEndInput"
            type="date"
            value={rangeEnd}
            onChange={(e) => onRangeEndChange(e.target.value)}
            className="w-full font-mono text-[13px] px-3 py-2 border-1.5 border-[var(--rule)] bg-white text-[var(--ink)] focus:outline-none focus:border-[var(--brass)]"
          />
        </div>
      </div>

      {isInvalid && (
        <div className="flex items-center gap-1.5 font-mono text-[11.5px] text-[var(--flag)] mb-2.5 font-semibold">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>The &ldquo;From&rdquo; date must be on or before the &ldquo;To&rdquo; date.</span>
        </div>
      )}

      {/* Quick Presets */}
      <div className="pt-2.5 border-t border-[var(--rule)] flex flex-wrap items-center gap-2">
        <span className="font-mono text-[10px] uppercase tracking-wider text-[#8a9086]">
          Quick Presets:
        </span>
        <button
          type="button"
          onClick={handleLastWeek}
          className="font-mono text-[10.5px] px-2 py-0.5 border border-[var(--rule)] bg-white hover:border-[var(--brass)] hover:bg-[var(--brass-light)]/30 text-[var(--ink)] transition-colors"
        >
          Last Week (Sat–Sun)
        </button>
        <button
          type="button"
          onClick={handleThisWeek}
          className="font-mono text-[10.5px] px-2 py-0.5 border border-[var(--rule)] bg-white hover:border-[var(--brass)] hover:bg-[var(--brass-light)]/30 text-[var(--ink)] transition-colors"
        >
          This Week
        </button>
        <button
          type="button"
          onClick={handlePast14Days}
          className="font-mono text-[10.5px] px-2 py-0.5 border border-[var(--rule)] bg-white hover:border-[var(--brass)] hover:bg-[var(--brass-light)]/30 text-[var(--ink)] transition-colors"
        >
          Past 14 Days
        </button>
        <button
          type="button"
          onClick={handleFullMonth}
          className="font-mono text-[10.5px] px-2 py-0.5 border border-[var(--rule)] bg-white hover:border-[var(--brass)] hover:bg-[var(--brass-light)]/30 text-[var(--ink)] transition-colors"
        >
          Current Month
        </button>
      </div>
    </div>
  );
};
