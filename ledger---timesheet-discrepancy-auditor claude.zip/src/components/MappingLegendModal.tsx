import React from 'react';
import { X, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { TYPE_MAP, TRACKED_TYPES, TRACKED_CATEGORIES } from '../utils/parser';

interface MappingLegendModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MappingLegendModal: React.FC<MappingLegendModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-[2px]">
      <div className="bg-[var(--paper)] border-2 border-[var(--ink)] w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl">
        <div className="p-4 sm:p-5 border-b border-[var(--ink)] flex items-center justify-between bg-white/70">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-widest text-[var(--brass)] font-semibold">
              Specification Matrix
            </div>
            <h2 className="font-serif font-bold text-2xl text-[var(--ink)]">
              Category Translation Matrix & Audit Scope
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[var(--ink)] hover:bg-black/10 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 custom-scrollbar text-[13px] leading-relaxed">
          {/* Active Scope Note */}
          <div className="border border-[var(--ok)] bg-[var(--ok-bg)] p-3.5 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[var(--ok)] shrink-0 mt-0.5" />
            <div>
              <div className="font-mono text-[11px] font-bold uppercase tracking-wider text-[var(--ok)]">
                Active Audit Scope (4 Tracked Types)
              </div>
              <div className="font-sans text-[12.5px] text-[#2c4033] mt-1">
                Ledger focuses strictly on updating and review update rows:
                <code className="bg-white/80 px-1 py-0.5 mx-1 font-mono text-[11px]">UpdatedReviewFull</code>,
                <code className="bg-white/80 px-1 py-0.5 mx-1 font-mono text-[11px]">UpdatedReviewLimited</code>,
                <code className="bg-white/80 px-1 py-0.5 mx-1 font-mono text-[11px]">UpdatedFull</code>, and
                <code className="bg-white/80 px-1 py-0.5 mx-1 font-mono text-[11px]">UpdatedLimited</code>. All other task rows are omitted from both sheets during investigation.
              </div>
            </div>
          </div>

          {/* Full Translation Table */}
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[var(--brass)] mb-2 font-bold">
              Complete Translation Table
            </div>
            <table className="w-full border-collapse border border-[var(--rule)] bg-white text-[12px] font-mono">
              <thead>
                <tr className="bg-[var(--paper)] text-[10.5px] uppercase tracking-wider text-[#5a6157] border-b border-[var(--rule)]">
                  <th className="p-2.5 text-left">Data Pull Type Code</th>
                  <th className="p-2.5 text-left">Axis</th>
                  <th className="p-2.5 text-left">Employer Daily Category</th>
                  <th className="p-2.5 text-center">In Audit Scope?</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(TYPE_MAP).map(([rawCode, data]) => {
                  const isTracked = TRACKED_TYPES.has(rawCode);
                  return (
                    <tr
                      key={rawCode}
                      className={`border-b border-[var(--rule)] ${
                        isTracked ? 'bg-[var(--ok-bg)]/40 font-semibold' : 'hover:bg-gray-50'
                      }`}
                    >
                      <td className="p-2.5 text-[var(--ink)] font-mono">{rawCode}</td>
                      <td className="p-2.5 capitalize text-[#5a6157]">{data.axis}</td>
                      <td className="p-2.5 text-[var(--ink)]">{data.category}</td>
                      <td className="p-2.5 text-center">
                        {isTracked ? (
                          <span className="inline-flex items-center gap-1 text-[var(--ok)] text-[11px] font-bold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Tracked
                          </span>
                        ) : (
                          <span className="text-[#8a9086] text-[11px]">Excluded</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Matching Criteria */}
          <div className="border border-[var(--rule)] p-4 bg-white space-y-2">
            <div className="font-mono text-[11px] uppercase tracking-wider text-[var(--brass)] mb-1 font-bold flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              Reconciliation Matching Rules
            </div>
            <ul className="list-disc list-inside space-y-1.5 font-sans text-[12.5px] text-[#3a4139]">
              <li>
                <strong>Asset Name Normalization</strong>: Names undergo punctuation and spacing normalization (e.g. <code className="bg-gray-100 px-1 font-mono">API Restauration</code> and <code className="bg-gray-100 px-1 font-mono">API-Restauration</code> match seamlessly).
              </li>
              <li>
                <strong>Window-Based Matching</strong>: Tasks match anywhere within the selected date window under <em>&ldquo;Pick the date range to audit&rdquo;</em>.
              </li>
              <li>
                <strong>Status Requirement</strong>: Tasks logged in the Data Pull Sheet must have a <code className="bg-gray-100 px-1 font-mono font-bold">Done</code> entry in the Daily Planning Sheet&apos;s <em>Status</em> column to match cleanly. Non-done statuses are flagged.
              </li>
            </ul>
          </div>
        </div>

        <div className="p-4 border-t border-[var(--ink)] bg-white/70 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="font-mono text-[11px] tracking-wider uppercase bg-[var(--ink)] text-[var(--paper)] px-5 py-2 hover:bg-[#2a3542] transition-colors"
          >
            Close Matrix
          </button>
        </div>
      </div>
    </div>
  );
};
