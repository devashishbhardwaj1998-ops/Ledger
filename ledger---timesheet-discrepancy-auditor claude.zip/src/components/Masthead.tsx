import React, { useState } from 'react';
import { FileSpreadsheet, Info, Sun, Moon } from 'lucide-react';

interface MastheadProps {
  onOpenLegend: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Masthead: React.FC<MastheadProps> = ({ onOpenLegend, darkMode, onToggleDarkMode }) => {
  const [refNum] = useState(() => String(Math.floor(1000 + Math.random() * 8999)).slice(0, 3));

  return (
    <header className="border-b-[3px] border-double border-[var(--ink)] pb-4 mb-8 flex flex-col md:flex-row justify-between items-start md:items-end gap-5">
      <div>
        <div className="font-mono text-[11px] font-medium tracking-[2.5px] uppercase text-[var(--brass)] mb-1 flex items-center gap-2">
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Timesheet Audit Desk</span>
        </div>
        <h1 className="font-serif font-bold text-4xl sm:text-5xl tracking-tight text-[var(--ink)] leading-none">
          Ledger
        </h1>
      </div>

      <div className="flex flex-col sm:flex-row md:flex-col items-start md:items-end gap-3">
        <div className="font-mono text-[11px] text-left md:text-right text-[#5a6157] leading-relaxed">
          <span className="font-bold text-[var(--ink)]">No. {refNum}</span>
          <br />
          One employee, task by task
          <br />
          self-logged vs. employer record
        </div>

        <button
          type="button"
          onClick={onOpenLegend}
          className="inline-flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-wider text-[var(--brass)] hover:text-[var(--ink)] border border-[var(--rule)] hover:border-[var(--brass)] px-2.5 py-1 transition-colors bg-white/50"
        >
          <Info className="w-3 h-3" />
          <span>Category Translation Matrix</span>
        </button>

        <button
          type="button"
          onClick={onToggleDarkMode}
          aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          className="inline-flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-wider text-[var(--brass)] hover:text-[var(--ink)] border border-[var(--rule)] hover:border-[var(--brass)] px-2.5 py-1 transition-colors bg-white/50"
        >
          {darkMode ? <Sun className="w-3 h-3" /> : <Moon className="w-3 h-3" />}
          <span>{darkMode ? 'Light Mode' : 'Dark Mode'}</span>
        </button>
      </div>
    </header>
  );
};
