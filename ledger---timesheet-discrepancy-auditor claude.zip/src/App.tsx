import React, { useState, useEffect, useRef } from 'react';
import { Play, AlertTriangle, ArrowRight } from 'lucide-react';
import { RawEmployeeRow, RawEmployerRow, AuditReportData } from './types';
import { lastWeekWindow, getDateSpan } from './utils/parser';
import { runInvestigation } from './utils/audit';
import { Masthead } from './components/Masthead';
import { IntakeSlots } from './components/IntakeSlots';
import { EmployeePicker } from './components/EmployeePicker';
import { DateRangePicker } from './components/DateRangePicker';
import { DiscrepancyReport } from './components/DiscrepancyReport';
import { MappingLegendModal } from './components/MappingLegendModal';

export default function App() {
  const [employeeFile, setEmployeeFile] = useState<{ name: string; sizeText?: string } | null>(null);
  const [employerFile, setEmployerFile] = useState<{ name: string; sizeText?: string } | null>(null);
  const [employeeRows, setEmployeeRows] = useState<RawEmployeeRow[] | null>(null);
  const [employerRows, setEmployerRows] = useState<RawEmployerRow[] | null>(null);

  const [selectedNameKey, setSelectedNameKey] = useState<string>('');
  const [selectedDisplayName, setSelectedDisplayName] = useState<string>('');
  const [typedName, setTypedName] = useState<string>('');

  const [rangeStart, setRangeStart] = useState<string>('');
  const [rangeEnd, setRangeEnd] = useState<string>('');
  const [rangeSource, setRangeSource] = useState<'detected' | 'manual' | 'default'>('default');
  const [detectedRange, setDetectedRange] = useState<{ start: string; end: string } | null>(null);

  const [report, setReport] = useState<AuditReportData | null>(null);
  const [errorNote, setErrorNote] = useState<string | null>(null);
  const [isLegendOpen, setIsLegendOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  const reportRef = useRef<HTMLDivElement>(null);

  // Initialize date range with sensible default (last week)
  useEffect(() => {
    const w = lastWeekWindow();
    setRangeStart(w.start);
    setRangeEnd(w.end);
  }, []);

  // Update selectedNameKey whenever typedName resolves directly or user picks from list
  const handleTypedNameChange = (val: string) => {
    setTypedName(val);
    if (!employeeRows || !employeeRows.length) return;

    const clean = val.trim().replace(/\s+/g, ' ');
    const lower = clean.toLowerCase();

    // Check exact nameKey match
    const hit = employeeRows.find((r) => r.nameKey === lower);
    if (hit) {
      setSelectedNameKey(hit.nameKey);
      setSelectedDisplayName(hit.name);
      return;
    }

    // Check split first / last
    const words = clean.split(' ');
    if (words.length >= 2) {
      const typedLast = words[words.length - 1].toLowerCase();
      const typedFirst = words.slice(0, -1).join(' ').toLowerCase();
      const splitHit = employeeRows.find(
        (r) =>
          r.firstName.toLowerCase() === typedFirst &&
          r.lastName.toLowerCase() === typedLast
      );
      if (splitHit) {
        setSelectedNameKey(splitHit.nameKey);
        setSelectedDisplayName(splitHit.name);
        return;
      }
    }

    setSelectedNameKey('');
    setSelectedDisplayName('');
  };

  const handleSelectEmployee = (nameKey: string, displayName: string) => {
    setSelectedNameKey(nameKey);
    setSelectedDisplayName(displayName);
    setTypedName(displayName);
    setErrorNote(null);
  };

  // Readiness calculations
  const filesReady = Boolean(employeeFile && employerFile && employeeRows && employerRows);
  const nameChosen = Boolean(selectedNameKey);
  const rangeChosen = Boolean(rangeStart && rangeEnd);
  const rangeValid = rangeChosen && rangeStart <= rangeEnd;
  const isReadyToInvestigate = filesReady && nameChosen && rangeValid;

  let statusMessage = 'Awaiting both files';
  if (!employeeFile && !employerFile) {
    statusMessage = 'Awaiting the Data Pull Sheet (Exhibit A) and the Daily Planning Sheet (Exhibit B).';
  } else if (!employeeFile) {
    statusMessage = 'Waiting on Exhibit A (Data Pull Sheet).';
  } else if (!employerFile) {
    statusMessage = 'Waiting on Exhibit B (Daily Planning Sheet or Google Sheet).';
  } else if (!nameChosen) {
    statusMessage = 'Type or select which employee to audit.';
  } else if (!rangeChosen) {
    statusMessage = 'Pick a date range to audit.';
  } else if (!rangeValid) {
    statusMessage = 'The "From" date must be on or before the "To" date.';
  } else {
    statusMessage = 'Ready to investigate.';
  }

  const handleInvestigate = () => {
    setErrorNote(null);
    if (!employeeRows || !employerRows || !selectedNameKey) return;

    try {
      const auditResult = runInvestigation(
        employeeRows,
        employerRows,
        selectedNameKey,
        selectedDisplayName,
        rangeStart,
        rangeEnd,
        employeeFile?.name || 'Exhibit A',
        employerFile?.name || 'Exhibit B'
      );
      setReport(auditResult);

      setTimeout(() => {
        const el = document.getElementById('report');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    } catch (err: any) {
      setErrorNote(err.message || 'Audit investigation failed.');
    }
  };

  return (
    <div className={`min-h-screen text-[var(--ink)]${darkMode ? ' dark' : ''}`}>
      <div className="max-w-[1060px] mx-auto px-4 sm:px-7 py-8 sm:py-12 pb-28">
        {/* Masthead */}
        <Masthead onOpenLegend={() => setIsLegendOpen(true)} darkMode={darkMode} onToggleDarkMode={() => setDarkMode((v) => !v)} />

        {/* Lede Explainer */}
        <div className="font-serif text-[15px] sm:text-[16.5px] leading-relaxed text-[#3a4139] max-w-3xl mb-8 border-l-2 border-[var(--rule)] pl-4 sm:pl-5">
          Upload the Data Pull Sheet and upload the Daily Planning Sheet in their respective sections. Ledger audits the selected employee&apos;s logged tasks on the Data Pull Sheet against the Daily Planning Sheet so that your Sundays are actually Sundays.
        </div>

        {/* Intake File Zones */}
        <IntakeSlots
          employeeFile={employeeFile}
          employerFile={employerFile}
          onEmployeeLoaded={(info, rows) => {
            setEmployeeFile(info);
            setEmployeeRows(rows);
            setErrorNote(null);
            // If previous selected name is in new rows, keep it; else clear
            if (selectedNameKey && !rows.some((r) => r.nameKey === selectedNameKey)) {
              setSelectedNameKey('');
              setSelectedDisplayName('');
              setTypedName('');
            }
            // The Data Pull Sheet always covers exactly one week — auto-set the
            // audit window to match it, since it's more reliable than guessing
            // a calendar Sat–Sun week. Still fully editable afterward.
            const span = getDateSpan(rows);
            if (span) {
              setDetectedRange(span);
              setRangeStart(span.start);
              setRangeEnd(span.end);
              setRangeSource('detected');
            } else {
              setDetectedRange(null);
            }
          }}
          onEmployerLoaded={(info, rows) => {
            setEmployerFile(info);
            setEmployerRows(rows);
            setErrorNote(null);
          }}
          onClearEmployee={() => {
            setEmployeeFile(null);
            setEmployeeRows(null);
            setSelectedNameKey('');
            setSelectedDisplayName('');
            setTypedName('');
            setReport(null);
          }}
          onClearEmployer={() => {
            setEmployerFile(null);
            setEmployerRows(null);
            setReport(null);
          }}
          onError={(msg) => setErrorNote(msg)}
        />

        {/* Employee Picker */}
        {employeeRows && employeeRows.length > 0 && (
          <EmployeePicker
            employeeRows={employeeRows}
            selectedNameKey={selectedNameKey}
            typedName={typedName}
            onTypedNameChange={handleTypedNameChange}
            onSelectEmployee={handleSelectEmployee}
          />
        )}

        {/* Date Range Picker */}
        <DateRangePicker
          rangeStart={rangeStart}
          rangeEnd={rangeEnd}
          detectedRange={detectedRange}
          rangeSource={rangeSource}
          onRangeStartChange={(val) => {
            setRangeStart(val);
            setRangeSource('manual');
            setErrorNote(null);
          }}
          onRangeEndChange={(val) => {
            setRangeEnd(val);
            setRangeSource('manual');
            setErrorNote(null);
          }}
          onApplyPreset={(start, end) => {
            setRangeStart(start);
            setRangeEnd(end);
            setRangeSource('manual');
            setErrorNote(null);
          }}
          onUseDetected={() => {
            if (!detectedRange) return;
            setRangeStart(detectedRange.start);
            setRangeEnd(detectedRange.end);
            setRangeSource('detected');
            setErrorNote(null);
          }}
        />

        {/* Action Trigger Row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 border border-[var(--ink)] bg-white/70">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[var(--brass)] shrink-0 animate-pulse" />
            <span className="font-mono text-[12px] text-[#5a6157]">
              {statusMessage}
            </span>
          </div>

          <button
            type="button"
            disabled={!isReadyToInvestigate}
            onClick={handleInvestigate}
            className="font-mono text-[13px] font-bold tracking-[1.5px] uppercase bg-[var(--ink)] text-[var(--paper)] px-8 py-3.5 hover:bg-[#2a3542] active:translate-y-[1px] disabled:bg-[#aab0a4] disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Investigate</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Error Note Banner */}
        {errorNote && (
          <div className="mt-4 p-4 bg-[var(--flag-bg)] border border-[var(--flag)] text-[var(--flag)] font-mono text-[12.5px] flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            <div className="whitespace-pre-wrap leading-relaxed">{errorNote}</div>
          </div>
        )}

        {/* Discrepancy Findings Report */}
        {report && (
          <div ref={reportRef}>
            <DiscrepancyReport report={report} />
          </div>
        )}

        {/* Footer */}
        <footer className="mt-20 pt-5 border-t border-[var(--rule)] font-mono text-[11px] text-[#8a9086] text-center leading-relaxed">
          Ledger runs entirely in this browser tab. Uploaded files are never sent anywhere; a linked Google Sheet is fetched directly from your browser to Google.
        </footer>
      </div>

      {/* Translation Table Specification Modal */}
      <MappingLegendModal
        isOpen={isLegendOpen}
        onClose={() => setIsLegendOpen(false)}
      />
    </div>
  );
}
