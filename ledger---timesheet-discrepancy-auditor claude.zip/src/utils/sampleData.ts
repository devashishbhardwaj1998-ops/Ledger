import { RawEmployeeRow, RawEmployerRow } from '../types';
import { normAsset, normDate } from './parser';

export function getSampleDataPullSheet(): RawEmployeeRow[] {
  const rawList = [
    // Arthur Pendelton - clean matches
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'Acme Corp Q3 Filing', date: '08-08-2026', mins: 45, type: 'UpdatedFull' },
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'BioTech Solutions Overview', date: '09-08-2026', mins: 60, type: 'UpdatedReviewFull' },
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'CyberSec Systems Guide', date: '10-08-2026', mins: 30, type: 'UpdatedLimited' },
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'Delta Logistics Audit Doc', date: '11-08-2026', mins: 40, type: 'UpdatedReviewLimited' },
    
    // Arthur Pendelton - Mismatches and Edge Cases
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'Echo Energy Prospectus', date: '10-08-2026', mins: 90, type: 'UpdatedFull' }, // Employer has Update (limited)
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'Falcon Aerospace Spec Sheet', date: '12-08-2026', mins: 55, type: 'UpdatedReviewFull' }, // Missing in employer sheet
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'GreenTech Environmental Brief', date: '13-08-2026', mins: 25, type: 'SpecialCustomCode' }, // Unmapped type
    
    // Arthur Pendelton - Outside tracked scope (ignored by design)
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'Hydra Dynamics Roadmap', date: '11-08-2026', mins: 120, type: 'FirstReview' },
    { first: 'Arthur', last: 'Pendelton', uid: 'EMP-104', asset: 'Ion Labs Whitepaper', date: '12-08-2026', mins: 80, type: 'Full' },

    // Eleanor Vance
    { first: 'Eleanor', last: 'Vance', uid: 'EMP-109', asset: 'Jupiter Media Campaign', date: '08-08-2026', mins: 50, type: 'UpdatedFull' },
    { first: 'Eleanor', last: 'Vance', uid: 'EMP-109', asset: 'Kite Robotics Dossier', date: '09-08-2026', mins: 35, type: 'UpdatedReviewLimited' },
    { first: 'Eleanor', last: 'Vance', uid: 'EMP-109', asset: 'Lunar Horizon Tech Memo', date: '10-08-2026', mins: 65, type: 'UpdatedReviewFull' },

    // Marcus Brody
    { first: 'Marcus', last: 'Brody', uid: 'EMP-215', asset: 'Matrix Global Summary', date: '09-08-2026', mins: 40, type: 'UpdatedLimited' },
    { first: 'Marcus', last: 'Brody', uid: 'EMP-215', asset: 'Nexus Health Protocol', date: '11-08-2026', mins: 75, type: 'UpdatedFull' }
  ];

  return rawList.map((r) => {
    const name = `${r.first} ${r.last}`.trim();
    return {
      name,
      nameKey: name.toLowerCase(),
      firstName: r.first,
      lastName: r.last,
      userId: r.uid,
      assetName: r.asset,
      assetKey: normAsset(r.asset),
      date: normDate(r.date),
      minutes: r.mins,
      type: r.type
    };
  });
}

export function getSampleEmployerPlanningSheet(): RawEmployerRow[] {
  const rawList = [
    // Matches Arthur Pendelton (Status Done)
    { asset: 'Acme Corp Q3 Filing', date: '08-08-2026', prod: 'Update (full)', rev: '', status: 'Done' },
    { asset: 'BioTech Solutions Overview', date: '09-08-2026', prod: '', rev: 'Update R (full)', status: 'Done' },
    { asset: 'CyberSec Systems Guide', date: '10-08-2026', prod: 'Update (limited)', rev: '', status: 'Done' },
    { asset: 'Delta Logistics Audit Doc', date: '11-08-2026', prod: '', rev: 'Update R (limited)', status: 'Done' },
    
    // Mismatches for Arthur Pendelton
    { asset: 'Echo Energy Prospectus', date: '10-08-2026', prod: 'Update (limited)', rev: '', status: 'Done' }, // Mismatch: Emp has UpdatedFull
    
    // Task on Employer sheet, missing from Arthur's log
    { asset: 'Omega Horizon Strategy Paper', date: '11-08-2026', prod: 'Update (full)', rev: '', status: 'Done' },
    { asset: 'Polaris Navigation Deck', date: '12-08-2026', prod: '', rev: 'Update R (full)', status: 'In Progress' },

    // Non-tracked category in employer record (e.g. standard Full)
    { asset: 'Quantum Computing Brief', date: '09-08-2026', prod: 'Full', rev: '', status: 'Done' }
  ];

  return rawList.map((r) => ({
    assetName: r.asset,
    assetKey: normAsset(r.asset),
    date: normDate(r.date),
    production: r.prod,
    review: r.rev,
    status: r.status
  }));
}
